function [Best_Cost_IN, Best_X_IN, Convergence_curve_IN] = FNO(nP, MaxIt, LB, UB, dim, fobj, ordered)
    %% ��ʼ��
    nV = dim;                        % ��������
    pr = 0.5;                        % ���ʲ���
    LB = ones(1, dim) .* LB;         % �±߽� 
    UB = ones(1, dim) .* UB;         % �ϱ߽�
    Cost = zeros(nP, 1);
    X = initialization(nP, nV, UB, LB); % ��ʼ������⼯
    Convergence_curve_IN = zeros(1, MaxIt); % ��ʼ����������

    for i = 1:nP
        Cost(i) = fobj(X(i, :));     % ����Ŀ�꺯��ֵ
    end

    [~, Ind] = sort(Cost);     
    Best_Cost_IN = Cost(Ind(1));     % ȷ�����Ž�
    Best_X_IN = X(Ind(1), :);
    Worst_Cost = Cost(Ind(end));     % ȷ������
    Worst_X = X(Ind(end), :);
    
    %% ���� w ֵ
    w = zeros(1, MaxIt);
    for i = 1:MaxIt
        w(i) = i / MaxIt;
    end
    for t = 1:MaxIt
        w(t) = 4 * w(t) * (1 - w(t));
    end

   
    
    %% ��ѭ��
    for it = 1:MaxIt
   
        % ���㷨�߼�
        sum_val = 0;

        % Loop over k from 0 to 10
        for k = 0:10
            % Calculate the binomial coefficient for non-integer n
            binom_coeff = gamma(ordered + 1) / (gamma(k + 1) * gamma(ordered - k + 1));
            
            % Add the term to the sum
            sum_val = sum_val + (-1)^k * binom_coeff;
        end
        t = sum_val;    
        
        % ���� y
        y = 1 - it / MaxIt;
        
        % ���� a
        q =8 * (exp(sqrt(y) - 0.5) + exp(0.5 - sqrt(y)) - 2);
        
        % ���� alpha
        alpha = t * w(it) * q;

        for i = 1:nP
            A1 = fix(rand(1, nP) * nP) + 1; % ���ѡ����Ⱥ�е��ĸ�λ��        
            r1 = A1(1); r2 = A1(2);   
            r3 = A1(3); r4 = A1(4);        
            
            Xm = (X(r1, :) + X(r2, :) + X(r3, :) + X(r4, :)) / 4; % �����ĸ�λ�õ�ƽ��ֵ
            ro = alpha * (2 * rand - 1); ro1 = alpha * (2 * rand - 1);        
            eps = 5e-3 * rand; % ����� epsilon
            
            EST = rand * ro * (Best_X_IN - X(i,:)) + rand * ro1 * (Xm - X(i,:)); Flag = 1; 
            FNES = FNESRule(t, ro1, Best_X_IN, Worst_X, X(i, :), X(r1, :), EST, eps, Xm, Flag, ordered);      
            EST = rand * ro * (Best_X_IN - X(i,:)) + rand * ro1 * (Xm - X(i,:));
            X1 = X(i, :) - FNES + EST; % 
            
            EST = rand * ro * (Best_X_IN - X(i,:)) + rand * ro1 * (Xm - X(i,:)); Flag = 2;
            FNES = FNESRule(t, ro1, Best_X_IN, Worst_X, X(i, :), X(r1, :), EST, eps, Xm, Flag, ordered); 
            EST = rand * ro * (Best_X_IN - X(i,:)) + rand * ro1 * (Xm - X(i,:));
            X2 = Best_X_IN - FNES + EST; %        
            
            Xnew = zeros(1, nV);
            for j = 1:nV                                                   
                ro = alpha * (2 * rand - 1);                       
                X3 = X(i, j) - ro * (X2(j) - X1(j));           
                ra = rand; rb = rand;
                Xnew(j) = ra * (rb * X1(j) + (1 - rb) * X2(j)) + (1 - ra) * X3; %         
            end
            
           
            
            % ����Ƿ񳬳������ռ䲢��������
            Flag4ub = Xnew > UB;
            Flag4lb = Xnew < LB;
            Xnew = (Xnew .* (~(Flag4ub + Flag4lb))) + UB .* Flag4ub + LB .* Flag4lb;                
            Xnew_Cost = fobj(Xnew);

            % �������λ��        
            if Xnew_Cost < Cost(i)
                X(i, :) = Xnew;
                Cost(i) = Xnew_Cost;
                if Cost(i) < Best_Cost_IN
                    Best_X_IN = X(i, :);
                    Best_Cost_IN = Cost(i);
                end            
            end
            
            % �������λ�� 
            if Cost(i) > Worst_Cost
                Worst_X = X(i, :);
                Worst_Cost = Cost(i);
            end
        end
        
        Convergence_curve_IN(it) = Best_Cost_IN;
        % ��ʾ������Ϣ
        %disp(['Iteration ' num2str(it) ': Best Fitness = ' num2str(Convergence_curve_IN(it))]);
    end
end


% FNESRule ����
function FNES = FNESRule(t,ro1, Best_X, Worst_X, X, Xr1, EST, eps, Xm, Flag, ordered)
    nV = size(X, 2);
    Delta = 2 * rand * abs(Xm - X); 
    Step = ((Best_X - Xr1) + Delta) / 2; 
    DelX = rand(1, nV) .* (abs(Step)).^ordered; 
    
    FNES = randn * ro1 * (2 * DelX .* X) / t.*(Best_X - Worst_X + eps); 
    if Flag == 1
        Xs = X - FNES + EST; %
    else
        Xs = Best_X - FNES + EST;
    end    
    yp = rand * (0.5 * (Xs + X) + rand * DelX); % 
    yq = rand * (0.5 * (Xs + X) - rand * DelX); % 
    FNES = randn * ro1 * (2 * DelX .* X) / t.*(yp - yq + eps); % 
end

% ��ʼ������
function X = initialization(nP, nV, UB, LB)
    X = rand(nP, nV) .* (UB - LB) + LB;
end

% ��������ɺ���
function z = Unifrnd(a, b, c, dim)
    a2 = a / 2;
    b2 = b / 2;
    mu = a2 + b2;
    sig = b2 - a2;
    z = mu + sig .* (2 * rand(c, dim) - 1);
end